#ifndef SPLITTER_H
#define SPLITTER_H
#include <stddef.h> /* size_t definition */
#include <stdlib.h>
#include <string.h>

enum 
{E_BAD_SOURCE=1, E_BAD_DESTINATION, E_NO_MEMORY, E_NO_ACTION, E_SMALL_SIZE};



#ifdef __cplusplus
extern "C" {
#endif
int SplitFile(char const *  filename,  char const * output, size_t size);
int JoinFiles(char** filenames, int num_files, char const * output);
#ifdef __cplusplus
}
#endif


#endif 

