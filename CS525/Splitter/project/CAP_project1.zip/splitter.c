/******************************************************************************/
/*!
\file   splitter.c
\author Cory Prelerson
\par    email: cory.prelerson@digipen.edu
\par    DigiPen login: cory.prelerson
\par    Course: CS525
\par    Assignment #1 - File Splitter
\date   9.15.2013
\brief  
  This is the implementation file for the File Splitter program. 
  
  Operations are:
	- Split a large file into several smaller files
	- Join several smaller files into one larger file
  
*/
/******************************************************************************/

#include <stdio.h>     /* printf, sprintf */
#include "splitter.h"  /* SplitFile, JoinFiles */
/********************************************************************/
/*!
		- BUFF_SIZE - maximum size of input buffer 
		
*/
/*******************************************************************/
#define BUFF_SIZE 4096
/*!
		- FILENAME_MAX_SIZE- maximum size for input or output file name
*/
#define FILENAME_MAX_SIZE 256


/********************************************************************/
/*!
	Splits larger file into several small chunks. Reads into a buffer
	of size min(size, \p BUFF_SIZE), then writes buffer out.
	
	\param filename
		File name for file to be split
	\param output
		File name prefix for smaller files
	\param size
		Size of chunks for file to be split into.
*/
/*******************************************************************/
int SplitFile(char const * filename, char const * output, size_t size) {
	char current_file_name[FILENAME_MAX_SIZE];
    int file_count=0;
	char * in_buffer;
	int bytes_read;
	FILE *inputfile;
	FILE *outputfile;
	
	if (size > BUFF_SIZE) size = BUFF_SIZE; /*! Input buffer size = min(size, BUFF_SIZE)*/
	
	in_buffer = (char*) malloc(size +1);
	
	memset(in_buffer,0,size);
	memset(current_file_name,0,FILENAME_MAX_SIZE-1);
	
	printf("In SplitFile\n\n");
	
	inputfile = fopen(filename, "rb");
	
	printf("File %s opened\n\n", filename);
	
	do{
		sprintf(current_file_name,"%s%04i", output, ++file_count);
		bytes_read = fread(in_buffer, 1, size, inputfile);
		if (bytes_read >0)
		{
			outputfile = fopen(current_file_name, "wb");
			fwrite(in_buffer,1,bytes_read,outputfile);
		}
		memset(in_buffer,0,size);
		fclose(outputfile);
	} while (bytes_read > 0);
	
	
	fclose(inputfile);
	free (in_buffer);
	return 0;
	
}


/********************************************************************/
/*!
	Joins several smaller files into one larger one. Reads from input 
	file into buffer, then writes buffer out to output file.
	
	\param filenames
		List of file names to be joined.
	\param num_files
		The number of files that are to be joined.
	\param output
		Name of the file created by joining the smaller files.
*/
/*******************************************************************/
int JoinFiles(char** filenames, int num_files, char const * output) {
	int i;
	/*int j = 0;*/
	char* in_buffer;
	/*char current_file_name[FILENAME_MAX_SIZE];*/
    
	FILE *combined_file;
	FILE *input_file;
	int bytes_read;
	
	printf("\nJoin Files\n");
	
	in_buffer = (char*)malloc(BUFF_SIZE);
	memset(in_buffer,0,BUFF_SIZE-1);
	
	if(filenames)
	{
		for ( i=0; i<num_files; ++i ) 
		{
			printf("%d:%s\n",i,filenames[i] );
		}
	}
	
	combined_file = fopen(output, "wb");
	printf("file opened\n");
	
	for (i = 0; i < num_files; i++)
	{
		memset(in_buffer,0, BUFF_SIZE-1);
		input_file = fopen(filenames[i],"rb");
		bytes_read = fread (in_buffer,1,BUFF_SIZE,input_file);
		fwrite (in_buffer, 1, bytes_read,combined_file);
		fputs(in_buffer,stderr);
		fclose(input_file);
	}
	
	fclose(combined_file);
    printf("into %s\n",output);
	free (in_buffer);
    return 0;
}


